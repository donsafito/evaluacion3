export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyB4ZcyYRegG6F63cfUuh39AaU_jh1Dhgj0",
    authDomain: "registrapp-f17e2.firebaseapp.com",
    projectId: "registrapp-f17e2",
    storageBucket: "registrapp-f17e2.appspot.com",
    messagingSenderId: "1092934618936",
    appId: "1:1092934618936:web:b636aad1dcdc1a91e4bbcd",
    measurementId: "G-3Z0ZN3L9G5"
  }
};
