import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false, 
   firebaseConfig : {
    apiKey: "AIzaSyB4ZcyYRegG6F63cfUuh39AaU_jh1Dhgj0",
    authDomain: "registrapp-f17e2.firebaseapp.com",
    projectId: "registrapp-f17e2",
    storageBucket: "registrapp-f17e2.appspot.com",
    messagingSenderId: "1092934618936",
    appId: "1:1092934618936:web:b636aad1dcdc1a91e4bbcd",
    measurementId: "G-3Z0ZN3L9G5"
  }
};



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
