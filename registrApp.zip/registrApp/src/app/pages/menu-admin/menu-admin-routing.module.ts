import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MenuAdminPage } from './menu-admin.page';

const routes: Routes = [
  {
    path: '',
    component: MenuAdminPage,
    children: [{
      
      
      
        path: 'administrador/:id',
        loadChildren: () => import('../administrador/administrador.module').then( m => m.AdministradorPageModule),
      },{
        path: 'asignaturas',
        loadChildren: () => import('../asignaturas/asignaturas.module').then( m => m.AsignaturasPageModule)
      },{path: 'micuenta-admin/:id',
      loadChildren: () => import('../micuenta-admin/micuenta-admin.module').then( m => m.MicuentaAdminPageModule)}  
      
]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MenuAdminPageRoutingModule {}
