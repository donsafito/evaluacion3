import { Component, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { Alert } from 'selenium-webdriver';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-administrador',
  templateUrl: './administrador.page.html',
  styleUrls: ['./administrador.page.scss'],
})
export class AdministradorPage implements OnInit {

  //variable grupo:
  usuario = new FormGroup({
    id: new FormControl('', Validators.required),
    rut: new FormControl('', [Validators.required, Validators.pattern('[0-9]{1,2}.[0-9]{3}.[0-9]{3}-[0-9kK]')]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    ap_paterno: new FormControl('', [Validators.required, Validators.minLength(3)]),
    fecha_nac: new FormControl('', [Validators.required]),
    correo: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(14)]),
    clave: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(18)]),
    tipo_usuario: new FormControl('', [Validators.required]),
    semestre: new FormControl('', [Validators.min(1), Validators.max(8)])
  });
  id_modificar: any = '';
  repetir_clave: string;
  usuarios: any[] = [];
  KEY_PERSONAS = 'personas';
  codigo = v4();
  v_agregar: boolean = false;
  correo : any;
  usuarioIngresado : any;
  rut : any;
  constructor(private usuarioService: UsuarioService, private alertController: AlertController, private validaciones: ValidacionesService, private storage: StorageService, private fireService: FireService, private activatedRoute: ActivatedRoute, private toastCtrl: ToastController) { }

  async ngOnInit() {
    this.usuario.controls.id.setValue(this.codigo);
    this.cargarDatos();

    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.fireService.getDato(this.KEY_PERSONAS, this.rut).subscribe(
      (response: any) => {
        this.usuarioIngresado = response.data();
      }
    );
  }
   
  //métodos:
  async toastMensaje(message: string){
    const toast = await this.toastCtrl.create({
      message,
      duration: 2000

    });
    toast.present();
  }

   cargarDatos(){
    
    this.fireService.getDatos(this.KEY_PERSONAS).subscribe(
      data => {
        this.usuarios = [];
        for(let usuario of data){
          console.log( usuario.payload.doc.data() );
          let usu = usuario.payload.doc.data();
          usu['id'] = usuario.payload.doc.id;
          this.usuarios.push( usu );
        }
      }
    );
  }

  registrar() {
     
       for(let u of this.usuarios){
           if(u.rut == this.usuario.controls.rut.value){
             this.toastMensaje('El rut ya se encuentra registrado.')
             return;
           }else if(u.correo == this.usuario.controls.correo.value){
            this.toastMensaje('El correo ya se encuentra registrado.')
            return;
           }
          }

       if (!this.validaciones.validarRut(this.usuario.controls.rut.value)) {
        this.toastMensaje('Rut incorrecto!');
        return;
      } 
        
       if (!this.validaciones.validarEdadMinima(17, this.usuario.controls.fecha_nac.value)) {
        this.toastMensaje('Edad mínima 17 años!');
        return ;
      }
  
      if (this.usuario.controls.clave.value != this.repetir_clave) {
        this.toastMensaje('Contraseñas no coinciden!');
        return ;
      }

      if (this.usuario.controls.tipo_usuario.value == 'alumno'){
          this.correo = this.usuario.controls.correo.value;
          this.usuario.controls.correo.setValue(this.correo+'@duocuc.cl');
      }else if(this.usuario.controls.tipo_usuario.value == 'docente') {
          this.correo = this.usuario.controls.correo.value;
          this.usuario.controls.correo.setValue(this.correo+'@profesor.duoc.cl');
      } else if (this.usuario.controls.tipo_usuario.value == 'administrador'){
          this.correo = this.usuario.controls.correo.value;
          this.usuario.controls.correo.setValue(this.correo+'@duoc.cl');
      }

       var registrado = this.fireService.agregar(this.KEY_PERSONAS,this.usuario.controls.id.value, this.usuario.value);
       if(registrado){
        this.toastMensaje('Usuario registrado correctamente')
         this.v_agregar = true;
         this.usuario.reset();
         this.repetir_clave = '';
         this.usuario.controls.id.setValue(v4());
         this.cargarDatos();
         }else{
          this.toastMensaje('No se puede registrar el usuario');
         }
  }
    
  

  buscar(id){
    this.fireService.getDato('personas', id).subscribe(
      (response: any) => {
        //console.log( response.data() );
        this.usuario.setValue( response.data() );
        this.id_modificar = response.id;
      }
    );
  }

   async eliminar(rutEliminar) {
    const alert =  this.alertController.create({
      header: '¿Seguro que desea eliminar este usuario?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('NO ELIMINA!');
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.fireService.eliminar(this.KEY_PERSONAS, rutEliminar);
           this.cargarDatos();
          },
        },
      ],
    });
   
    
    await (await alert).present();
  }

  async modificar() {
   
    
    this.toastMensaje('Usuario modificado!');
    let usu = this.usuario.value;
    this.fireService.modificar(this.KEY_PERSONAS, this.id_modificar, usu);
    this.usuario.reset();
    this.id_modificar = '';
    
  }

 

  //método para cerrar sesión:
  logout(){
    this.usuarioService.logout();
  }

}
