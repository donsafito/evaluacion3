import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministradorPage } from './administrador.page';

describe('AdministradorPage', () => {
  let component: AdministradorPage;
  let fixture: ComponentFixture<AdministradorPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministradorPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministradorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('1. Levantar la página Administrador', ()=>{
    const fixture = TestBed.createComponent(AdministradorPage);
    const app = fixture.componentInstance;
    
    expect(app).toBeTruthy();
  });
  it('2. Formulario inválido', ()=> {
    const fixture = TestBed.createComponent(AdministradorPage);
    const app = fixture.componentInstance;

    let rut = app.usuario.controls['rut'];
    rut.setValue('20208051-0');

    expect(app.usuario.valid).toBeFalse();
  });

  it('3. Formulario válido', ()=> {
    const fixture = TestBed.createComponent(AdministradorPage);
    const app = fixture.componentInstance;
    
    let rut = app.usuario.controls['rut'];
    let nombre = app.usuario.controls['nombre'];
    rut.setValue('20208051-0');
    nombre.setValue('Armando');
    
    expect(app.usuario.valid).toBeTrue();
  });
  

  it('4. Ejecutar el boton agregar', ()=>{
    const fixture = TestBed.createComponent(AdministradorPage);
    const app = fixture.componentInstance;
    
    let rut = app.usuario.controls['rut'];
    let nombre = app.usuario.controls['nombre'];
    rut.setValue('20208051-0');
    nombre.setValue('Beatriz');
  
    app.registrar();

    expect(app.registrar).toBeTrue();
  });
});
