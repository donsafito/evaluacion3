import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { IonInput, IonTabs, ToastController } from '@ionic/angular';
import { now } from '@ionic/core/dist/types/utils/helpers';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';
import { v4} from 'uuid';


@Component({
  selector: 'app-qr',
  templateUrl: './qr.page.html',
  styleUrls: ['./qr.page.scss'],
})
export class QrPage implements OnInit {
  rut: string;
  usuario: any;
  asignaturast: any[] = [];
  clases: any[] = [];
  datos: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  KEY_CLASES = 'clases';
  KEY_PERSONAS = 'personas';
  codigo = v4();
  listado: any[] = [];
  hoy : string = new Date().toDateString();
  //VARIABLES PARA CREAR NUESTRO CÓDIGO QR:
  elementType = 'canvas';
  value = '';

    dato = {
      id: '',
      id_asig: '',
      fecha: '',
      alumnos: []
    };

    constructor(private router: Router,private storage: StorageService, private activatedRoute: ActivatedRoute, private fireService: FireService, private toastController: ToastController) { }

 async ngOnInit() {
    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.fireService.getDato(this.KEY_PERSONAS, this.rut).subscribe(
      (response: any) => {
        this.usuario = response.data();
      }
    );
    console.table(this.usuario);
    this.dato.id = await v4();
    await this.cargarDatos();
  }
  
  //métodos:
  async toastMensaje(message: string){
    const toast = await this.toastController.create({
      message,
      duration: 2000

    });
    toast.present();
  } 

  async cargarDatos(){
    
    this.fireService.getDatos(this.KEY_CLASES).subscribe(
      data => {
        this.clases = [];
        for(let clas of data){
          console.log( clas.payload.doc.data() );
          let usu = clas.payload.doc.data();
          usu['id'] = clas.payload.doc.id;
          this.clases.push( usu );
        }
      }
    );

    this.fireService.getDatos(this.KEY_ASIGNATURAS).subscribe(
      data => {
        this.asignaturast = [];
        for(let asig of data){
          console.log( asig.payload.doc.data() );
          let usu = asig.payload.doc.data();
          usu['id'] = asig.payload.doc.id;
          this.asignaturast.push( usu );
        }
      }
    );
    this.dato.fecha = this.hoy;
  }
  
  async agregarClase(){
    
    for(let c of this.clases){
      if(c.fecha == this.dato.fecha && c.id_asig == this.dato.id_asig){
        this.toastMensaje('Ya se registro la clase del dia de hoy.')
        return;
     }
    }

    if(this.dato.id_asig != ''){
      var registrada =  this.fireService.agregar(this.KEY_CLASES,this.dato.id, this.dato);
      this.value = this.dato.id
      if(registrada){
           this.toastMensaje('Clase creada correctamente');
           this.dato.id = (v4());
           this.dato.fecha = this.hoy;
           this.dato.alumnos = this.listado;
           await this.cargarDatos();
        }else{
        this.toastMensaje('No se pudo crear la clase.')
        }
      }else{
        this.toastMensaje('debe seleccionar un campo.')
        
      }
      }
}
