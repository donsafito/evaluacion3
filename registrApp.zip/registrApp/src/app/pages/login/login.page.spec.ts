import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AngularFireModule } from '@angular/fire/compat';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { environment } from 'src/environments/environment';

import { LoginPage } from './login.page';

describe('PRUEBA UNITARIAS: loginPage', ()=>{
  
  //configurar nuestro ambiente de pruebas:
  beforeEach( async ()=>{
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        AngularFireModule.initializeApp(environment.firebaseConfig)
      ],
      declarations: [
        LoginPage
      ]
    }).compileComponents();
  });


  it('1. Levantar la página Login', ()=>{
    const fixture = TestBed.createComponent(LoginPage);
    const app = fixture.componentInstance;
    
    expect(app).toBeTruthy();
  });
  
  it('2. Formulario inválido', ()=> {
    const fixture = TestBed.createComponent(LoginPage);
    const app = fixture.componentInstance;

    let rut = app.usuario.controls['rut'];
    rut.setValue('20.208.051-0');

    expect(app.usuario.valid).toBeFalse();
  });

  it('3. Formulario válido', ()=> {
    const fixture = TestBed.createComponent(LoginPage);
    const app = fixture.componentInstance;
    
    let rut = app.usuario.controls['rut'];
    let nombre = app.usuario.controls['nombre'];
    rut.setValue('02930391-k');
    nombre.setValue('Beatriz');
    
    expect(app.usuario.valid).toBeTrue();
  });
  

})