import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { UsuarioService } from 'src/app/services/usuario.service';
import { StorageService } from 'src/app/services/storage.service';
import { FireService } from 'src/app/services/fire.service';
import { BehaviorSubject } from 'rxjs';




@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
 
  //vamos a crear variables:
  usuario = new FormGroup({
    correo: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@(duoc|duocuc|profesor.duoc).(cl)')]),
    clave: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(18)])
  });
  KEY_PERSONAS = 'personas';
  usuarios: any[] = [];
  isAuntenticated = new BehaviorSubject(false);
  constructor(private toastController: ToastController, private router: Router, 
    private usuarioService: UsuarioService, private storage: StorageService, private fireService: FireService) { }

 async ngOnInit() {
  
  this.fireService.getDatos(this.KEY_PERSONAS).subscribe(
    data => {
      this.usuarios = [];
      for(let usuario of data){
        console.log( usuario.payload.doc.data() );
        let usu = usuario.payload.doc.data();
        usu['id'] = usuario.payload.doc.id;
        this.usuarios.push( usu );
      }
    }
  );
  
  

}
  
  //crear nuestro métodos:
  async toastMensaje(message: string){
    const toast = await this.toastController.create({
      message,
      duration: 2000

    });
    toast.present();
  } 
 encontrarUsuario(correo,password){
  var usuarioLogin = this.usuarios.find(dato => dato.correo == correo && dato.clave == password )
  return usuarioLogin;
  
 }
  

 
 async ingresar(){
  
  //rescatamos las variables del formulario por separado:
    var correoValidar = this.usuario.controls.correo.value;
    var claveValidar = this.usuario.controls.clave.value;

    //rescatamos el usuario con el método login usuario:
    var usuarioLogin = this.encontrarUsuario(correoValidar, claveValidar);
    this.fireService.validarLogin(usuarioLogin);
    //validamos si existe el usuario
    if(usuarioLogin != undefined){
      //AQUI, ANTES DE REDIRECCIONAR HACIA OTRA PÁGINA, PREPARAREMOS LOS DATOS QUE QUEREMOS ENVIAR:
      var navigationExtras: NavigationExtras = {
        state: {
          usuario: usuarioLogin
        }
      };
      //redirigimos dependiente del tipo de usuario
      if (usuarioLogin.tipo_usuario == 'administrador') {
        this.router.navigate(['/menu-admin'], navigationExtras);
      }else if(usuarioLogin.tipo_usuario == 'alumno'){
        this.router.navigate(['/alumno'], navigationExtras);
      }else if(usuarioLogin.tipo_usuario == 'docente'){
        this.router.navigate(['/docente'], navigationExtras);
    }else{
      this.toastMensaje('Usuario o contraseña incorrectos!')
      this.router.navigate(['/inicio']);
    }
  }
  }

}