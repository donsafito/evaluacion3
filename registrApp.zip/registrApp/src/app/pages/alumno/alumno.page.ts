import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from 'src/app/services/storage.service';
import { ClasePage } from '../clase/clase.page';

@Component({
  selector: 'app-alumno',
  templateUrl: './alumno.page.html',
  styleUrls: ['./alumno.page.scss'],
})
export class AlumnoPage implements OnInit {
  usuario: any;

  id_clase: '';
  asignaturast: any[] = [];
  clasest: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  KEY_CLASES = 'clases';
  KEY_PERSONAS = 'personas'
  hoy : string = new Date().toDateString();
  
  constructor(private router: Router, private storage: StorageService, private activatedRoute: ActivatedRoute) { }

  async ngOnInit() {
    this.usuario = this.router.getCurrentNavigation().extras.state.usuario;
   
  }

  
}
