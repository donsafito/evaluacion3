import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MicuentaAdminPage } from './micuenta-admin.page';

describe('MicuentaAdminPage', () => {
  let component: MicuentaAdminPage;
  let fixture: ComponentFixture<MicuentaAdminPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MicuentaAdminPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MicuentaAdminPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('1. Levantar la página mi cuenta administrador', ()=>{
    const fixture = TestBed.createComponent(MicuentaAdminPage);
    const app = fixture.componentInstance;
    
    expect(app).toBeTruthy();
  });
});
