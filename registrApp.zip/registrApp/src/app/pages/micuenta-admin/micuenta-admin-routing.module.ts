import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MicuentaAdminPage } from './micuenta-admin.page';

const routes: Routes = [
  {
    path: '',
    component: MicuentaAdminPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MicuentaAdminPageRoutingModule {}
