import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MicuentaAdminPageRoutingModule } from './micuenta-admin-routing.module';

import { MicuentaAdminPage } from './micuenta-admin.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MicuentaAdminPageRoutingModule
  ],
  declarations: [MicuentaAdminPage]
})
export class MicuentaAdminPageModule {}
