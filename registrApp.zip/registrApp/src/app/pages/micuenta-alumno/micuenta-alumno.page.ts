import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-micuenta-alumno',
  templateUrl: './micuenta-alumno.page.html',
  styleUrls: ['./micuenta-alumno.page.scss'],
})
export class MicuentaAlumnoPage implements OnInit {

  //VAMOS A CREAR UNA VARIABLE QUE RECIBA LOS DATOS DEL USUARIO DESDE LOGIN:
  rut: string;
  usuario: any = {};
  KEY_PERSONAS = 'personas';

  constructor(private activatedRoute: ActivatedRoute, private fireService: FireService) { }

   async ngOnInit() {
    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.fireService.getDato(this.KEY_PERSONAS, this.rut).subscribe(
      (response: any) => {
        this.usuario = response.data();
      }
    );
  }
  

}
