import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FireService } from 'src/app/services/fire.service';


@Component({
  selector: 'app-micuenta',
  templateUrl: './micuenta.page.html',
  styleUrls: ['./micuenta.page.scss'],
})
export class MicuentaPage implements OnInit {
  rut: string;
  usuario: any = {};
  KEY_PERSONAS = 'personas';
  constructor(private activatedRoute: ActivatedRoute, private fireService: FireService) { }

   ngOnInit() {
    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.fireService.getDato(this.KEY_PERSONAS, this.rut).subscribe(
      (response: any) => {
        this.usuario = response.data();
      }
    );


  }

}
