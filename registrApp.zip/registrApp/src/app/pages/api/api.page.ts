import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-api',
  templateUrl: './api.page.html',
  styleUrls: ['./api.page.scss'],
})
export class ApiPage implements OnInit {

  //variables auxiliares para trabajar las peticiones
  cantidad_personas: number = 0;
  personajes: any[] = [];

  constructor(private apiService: ApiService) {}

  async ngOnInit() {
    //llamar al metodo q obtiene a todas las personas
    let respuesta = await this.apiService.get();

    respuesta.subscribe( (data:any) => {
      console.log(data);
      this.cantidad_personas = data.info.count;
      this.personajes = data.results;
    });

  }

}
