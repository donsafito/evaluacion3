import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-registrar',
  templateUrl: './registrar.page.html',
  styleUrls: ['./registrar.page.scss'],
})
export class RegistrarPage implements OnInit {

  //variable grupo:
  usuario = new FormGroup({
    id: new FormControl('', Validators.required),
    rut: new FormControl('', [Validators.required, Validators.pattern('[0-9]{1,2}.[0-9]{3}.[0-9]{3}-[0-9kK]')]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    ap_paterno: new FormControl('', [Validators.required, Validators.minLength(3)]),
    fecha_nac: new FormControl('', [Validators.required]),
    correo: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(14)]),
    clave: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(18)]),
    tipo_usuario: new FormControl('alumno', [Validators.required]),
    semestre: new FormControl('', [Validators.min(1), Validators.max(8)])
  });
  repetir_clave: string;

  constructor(private usuarioService: UsuarioService, private validaciones: ValidacionesService, private router: Router, private storage: StorageService, private fireService: FireService) { }
  usuarios: any[] = [];
  KEY_PERSONAS = 'personas';
  codigo = v4();
  v_agregar = false;
  correo : any;

 async  ngOnInit() {
    this.usuario.controls.id.setValue(this.codigo);
    await this.cargarDatos();
  }
   //métodos:
   cargarDatos(){
    
    this.fireService.getDatos(this.KEY_PERSONAS).subscribe(
      data => {
        this.usuarios = [];
        for(let usuario of data){
          console.log( usuario.payload.doc.data() );
          let usu = usuario.payload.doc.data();
          usu['id'] = usuario.payload.doc.id;
          this.usuarios.push( usu );
        }
      }
    );
  }
  //métodos:
  registrar() {
     
    for(let u of this.usuarios){
        if(u.rut == this.usuario.controls.rut.value){
          alert('El rut ya se encuentra registrado.')
          return;
        }else if(u.correo == this.usuario.controls.correo.value){
         alert('El correo ya se encuentra registrado.')
         return;
        }
       }

    if (!this.validaciones.validarRut(this.usuario.controls.rut.value)) {
     alert('Rut incorrecto!');
     return;
   } 
     
    if (!this.validaciones.validarEdadMinima(17, this.usuario.controls.fecha_nac.value)) {
     alert('Edad mínima 17 años!');
     return ;
   }

   if (this.usuario.controls.clave.value != this.repetir_clave) {
     alert('Contraseñas no coinciden!');
     return ;
   }
    this.correo = this.usuario.controls.correo.value;
    this.usuario.controls.correo.setValue(this.correo+'@duocuc.cl');
    var registrado = this.fireService.agregar(this.KEY_PERSONAS,this.usuario.controls.id.value, this.usuario.value);
    if(registrado){
      alert('Usuario registrado correctamente')
      this.v_agregar = true;
      this.usuario.reset();
      this.repetir_clave = '';
      this.usuario.controls.id.setValue(v4());
      this.cargarDatos();
      this.router.navigate(['/login']);
      }else{
       alert('No se puede registrar el usuario');
      }
}

}
