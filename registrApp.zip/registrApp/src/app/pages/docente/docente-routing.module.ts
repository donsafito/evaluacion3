import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DocentePage } from './docente.page';

const routes: Routes = [
  {
    path: '',
    component: DocentePage,
    children: [{
      
      
        path: 'micuenta/:id',
        loadChildren: () => import('../micuenta/micuenta.module').then( m => m.MicuentaPageModule),
    },{
          path: 'qr/:id',
          loadChildren: () => import('../qr/qr.module').then( m => m.QrPageModule),
    },{
        path: 'qrcode',
        loadChildren: () => import('../qrcode/qrcode.module').then( m => m.QrcodePageModule)
      
    }  
        
  ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DocentePageRoutingModule {}
