import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-escanear',
  templateUrl: './escanear.page.html',
  styleUrls: ['./escanear.page.scss'],
})
export class EscanearPage implements OnInit {

  usuario: any = {};
  rut: string;
  id_clase: '';
  rutusar : string;
  asignaturast: any[] = [];
  clasest: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  KEY_CLASES = 'clases';
  KEY_PERSONAS = 'personas'
  hoy : string = new Date().toDateString();
  claseHoy : any = {};
  idEncontrado : any = {};

    dato = {
    id_asignatura: ''
    };

  constructor(private router: Router, private storage: StorageService, private activatedRoute: ActivatedRoute, private fireService: FireService, private toastController: ToastController) { }

  async ngOnInit() {
    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.fireService.getDato(this.KEY_PERSONAS, this.rut).subscribe(
      (response: any) => {
        this.usuario = response.data();
      }
    );
    this.fireService.getDatos(this.KEY_CLASES).subscribe(
      data => {
        this.clasest = [];
        for(let clas of data){
          console.log( clas.payload.doc.data() );
          let usu = clas.payload.doc.data();
          usu['id'] = clas.payload.doc.id;
          this.clasest.push( usu );
        }
      });
    

    this.fireService.getDatos(this.KEY_ASIGNATURAS).subscribe(
      data => {
        this.asignaturast = [];
        for(let asig of data){
          console.log( asig.payload.doc.data() );
          let usu = asig.payload.doc.data();
          usu['id'] = asig.payload.doc.id;
          this.asignaturast.push( usu );
        }
  });
}
  async toastMensaje(message: string){
    const toast = await this.toastController.create({
      message,
      duration: 2000

    });
    toast.present();
  }; 
  
    
      
    
  
  
  
  
    async registrarAsistencia(){
      await this.fireService.getDato(this.KEY_CLASES,this.dato.id_asignatura).subscribe(
        (response: any) => {
          this.idEncontrado = response.data();
        }
      );
  
        if(await this.idEncontrado != undefined){
          
          if(await this.idEncontrado.alumnos.includes(this.usuario.rut)){
              await this.toastMensaje('Usted ya se encuentra presente');
              this.dato.id_asignatura = '';
              this.idEncontrado = {};
            }else{
                await this.idEncontrado.alumnos.push(this.usuario.rut);
                await this.fireService.modificar(this.KEY_CLASES,this.idEncontrado.id,this.idEncontrado);
                await this.toastMensaje('Se registro correctamente su asistencia.');
                 this.dato.id_asignatura = '';
                 this.idEncontrado = {};
            }
          }
        }
      }