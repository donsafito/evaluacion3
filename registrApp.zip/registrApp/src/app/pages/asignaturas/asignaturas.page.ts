import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController, ToastController } from '@ionic/angular';
import { FireService } from 'src/app/services/fire.service';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-asignaturas',
  templateUrl: './asignaturas.page.html',
  styleUrls: ['./asignaturas.page.scss'],
})
export class AsignaturasPage implements OnInit {
  //variable grupo:
  asignatura = new FormGroup({
    id: new FormControl('', Validators.required),
    sigla: new FormControl('', [Validators.required, Validators.minLength(3)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    docente: new FormControl('', [Validators.required]),
    cant_alumnos: new FormControl('', [Validators.required, Validators.min(5), Validators.max(40)]),
    escuela: new FormControl('', [Validators.required, Validators.minLength(3)])
  });
  
  id_modificar: any = '';
  KEY_PERSONAS = 'personas'
  personas: any[] = [];
  asignaturast: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  codigo = v4();
  constructor(private usuarioService: UsuarioService, private alertController: AlertController, private validaciones: ValidacionesService, private storage: StorageService, private fireService: FireService, private toastController: ToastController) { }

  async ngOnInit() {
    this.asignatura.controls.id.setValue(this.codigo);
    await this.cargarDatos();
  }
  
   //métodos:
   async toastMensaje(message: string){
    const toast = await this.toastController.create({
      message,
      duration: 2000

    });
    toast.present();
  } 

   async cargarDatos(){
    
    this.fireService.getDatos(this.KEY_PERSONAS).subscribe(
      data => {
        this.personas = [];
        for(let pers of data){
          console.log( pers.payload.doc.data() );
          let usu = pers.payload.doc.data();
          usu['id'] = pers.payload.doc.id;
          this.personas.push( usu );
        }
      }
    );

    this.fireService.getDatos(this.KEY_ASIGNATURAS).subscribe(
      data => {
        this.asignaturast = [];
        for(let asig of data){
          console.log( asig.payload.doc.data() );
          let usu = asig.payload.doc.data();
          usu['id'] = asig.payload.doc.id;
          this.asignaturast.push( usu );
        }
      }
    );
  }

  async registrar() {
    
    for(let a of this.asignaturast){
      if(a.sigla == this.asignatura.controls.sigla.value){
        this.toastMensaje('La asignatura ya se encuentra registrada.')
        return;
      
     }
    }

    this.asignatura.controls.id.setValue(v4());
    var registrado = this.fireService.agregar(this.KEY_ASIGNATURAS,this.asignatura.controls.id.value, this.asignatura.value);
    if(registrado){
      this.toastMensaje('Registrada Correctamente');
      await this.cargarDatos();
      this.asignatura.controls.id.setValue(v4());
      this.asignatura.reset();
    }else{
      this.toastMensaje('Asignatura no registrada.')
    }
  }

  buscar(id){
    this.fireService.getDato(this.KEY_ASIGNATURAS, id).subscribe(
      (response: any) => {
        //console.log( response.data() );
        this.asignatura.setValue( response.data() );
        this.id_modificar = response.id;
      }
    );
  }

  async eliminar(asigEliminar) {
    const alert =  this.alertController.create({
      header: '¿Seguro que desea eliminar esta asignatura?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('NO ELIMINA!');
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.fireService.eliminar(this.KEY_ASIGNATURAS, asigEliminar);
            
            this.asignatura.reset();
            this.asignatura.controls.id.setValue(v4());
           this.cargarDatos();
          },
        },
      ],
    });
   
    
    await (await alert).present();
  }

  async modificar() {
   
    
    this.toastMensaje('Asignatura modificada!');
    let asig = this.asignatura.value;
    this.fireService.modificar(this.KEY_ASIGNATURAS, this.id_modificar, asig);
    this.asignatura.reset();
    this.id_modificar = '';
    
  }

 

  //método para cerrar sesión:
  logout(){
    this.usuarioService.logout();
  }


}
