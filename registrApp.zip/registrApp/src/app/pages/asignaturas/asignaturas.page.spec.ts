import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AsignaturasPage } from './asignaturas.page';

describe('AsignaturasPage', () => {
  let component: AsignaturasPage;
  let fixture: ComponentFixture<AsignaturasPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AsignaturasPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AsignaturasPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('1. Levantar la página Asignatura', ()=>{
    const fixture = TestBed.createComponent(AsignaturasPage);
    const app = fixture.componentInstance;
    
    expect(app).toBeTruthy();
  });
  it('2. Formulario inválido', ()=> {
    const fixture = TestBed.createComponent(AsignaturasPage);
    const app = fixture.componentInstance;

    let sigla = app.asignatura.controls['sigla'];
    sigla.setValue('20208051-0');

    expect(app.asignatura.valid).toBeFalse();
  });

  it('3. Formulario válido', ()=> {
    const fixture = TestBed.createComponent(AsignaturasPage);
    const app = fixture.componentInstance;
    
    let sigla = app.asignatura.controls['sigla'];
    let nombre = app.asignatura.controls['nombre'];
    sigla.setValue('MDY2121');
    nombre.setValue('Modelamiento de base de datos');
    
    expect(app.asignatura.valid).toBeTrue();
  });
  

  it('4. Ejecutar el boton agregar', ()=>{
    const fixture = TestBed.createComponent(AsignaturasPage);
    const app = fixture.componentInstance;
    
    let sigla = app.asignatura.controls['sigla'];
    let nombre = app.asignatura.controls['nombre'];
    sigla.setValue('MDY2121');
    nombre.setValue('Modelamiento de base de datos');
  
    app.registrar();

    expect(app.registrar).toBeTrue();
  });
});

