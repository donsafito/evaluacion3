import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { ToastController } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class FireService {
  datos : any[] = [] ;
  isAuntenticated = new BehaviorSubject(false);
  constructor(private fire: AngularFirestore, private toastController: ToastController) { }
 
  async toastMensaje(message: string){
    const toast = await this.toastController.create({
      message,
      duration: 2000

    });
    toast.present();
  } 

  agregar(coleccion,id, value){
    try {
      this.fire.collection(coleccion).doc(id).set(value)
      return true;
    } catch (error) {
      console.log(error)
      return false;
    }
  }
  eliminar(coleccion, id){
    try {
      this.fire.collection(coleccion).doc(id).delete();
    } catch (error) {
      console.log(error);
    }
  }
  modificar(coleccion, id, value){
    try {
      this.fire.collection(coleccion).doc(id).set(value)
    } catch (error) {
      console.error(error);
    }
  }
  getDatos(coleccion){
    try {
      return this.fire.collection(coleccion).snapshotChanges();
    } catch (error) {
      console.log(error);
    }
  }
  getDato(coleccion, id){
    try {
      return this.fire.collection(coleccion).doc(id).get();
    } catch (error) {
      console.log(error);
    }
  }

  getAuth(){
    return this.isAuntenticated.value;
  }

  validarLogin(usuarioLogin){
  if(usuarioLogin != undefined){
    this.isAuntenticated.next(true);
  }else{
    this.toastMensaje('Usuario o contraseña incorrectos.')
  }
}
  
}
