import { Injectable } from '@angular/core';

//libreria para realizar peticiones del tipo HTTP;
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  //crear un metodo para realizar una peticion
  async get(){
    return await this.http.get('https://rickandmortyapi.com/api/character');
  }
}
