import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Storage } from '@ionic/storage-angular';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class StorageService {
  datos : any[] = [] ;
  
  isAuntenticated = new BehaviorSubject(false);
  constructor(private storage: Storage) { 
      storage.create();
  }
  async agregar(key, dato){
    var validarRut = await this.validarRut(key, dato.rut);
    var validarCorreo = await this.validarCorreo(key, dato.correo);
    if(validarRut == undefined && validarCorreo == undefined){
      this.datos = await this.storage.get(key) || [];
      this.datos.push(dato);
      await this.storage.set(key, this.datos);
      return true;
    }else{
      return false
    }}
   
    async agregarAsignatura(key, dato){
      
        this.datos = await this.storage.get(key) || [];
        this.datos.push(dato);
        await this.storage.set(key, this.datos);
        return true;

  }
  async agregarClase(key, dato){
      
    this.datos = await this.storage.get(key) || [];
    this.datos.push(dato);
    await this.storage.set(key, this.datos);
    return true;

 }

  async getDato(key, identificador){
    this.datos = await this.storage.get(key) || [];
    return this.datos.find(dato => dato.id == identificador);
  }
   
  async getDatos(key){
    this.datos = await this.storage.get(key) || [];
    return this.datos;
  }
  async eliminar(key, identificador){
    this.datos = await this.storage.get(key) || [];

    this.datos.forEach((value, index) => {
      if(value.id == identificador){
        this.datos.splice(index, 1);
      }
    });
    await this.storage.set(key, this.datos);
  }
  async actualizar(key, dato){
    this.datos = await this.storage.get(key) || [];

    var index = this.datos.findIndex(value => value.id == dato.id);
    this.datos[index] = dato;
    await this.storage.set(key, this.datos);
  }

  async validarLogin(key, correo, password){
  this.datos = await this.storage.get(key) || [];
  var usuarioLogin = this.datos.find(dato => dato.correo == correo && dato.clave == password )
  if(usuarioLogin != undefined){
    this.isAuntenticated.next(true);
    return usuarioLogin;
  }
  alert('No se puede acceder.')
  }
  
 async validarCorreo(key, correo){
    this.datos = await this.storage.get(key) || [];
    return this.datos.find( dato => dato.correo == correo);
    
  }
  
  async getClase(key, identificador, fecha){
    this.datos = await this.storage.get(key) || [];
    return this.datos.find(dato => dato.id_asig == identificador && dato.fecha == fecha);
  }
   

  async validarRut(key, rut){
    this.datos = await this.storage.get(key) || [];
    return this.datos.find( dato => dato.rut == rut)
  }

  async validarFecha(key, identificador, fecha){
    this.datos = await this.storage.get(key) || [];
    return this.datos.find( dato => dato.id_asig == identificador && dato.fecha == fecha)
  }
}

